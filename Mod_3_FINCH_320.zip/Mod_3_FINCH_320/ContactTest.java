
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactTest {
    Contact contact = new Contact("1", "firstName", "lastName", "123456789", "fake address 10111");

    void getContactID() {
        assertEquals("1", contact.getContactID());
    }

    
    void getFirstName() {
        assertEquals("firstName", contact.getFirstName());
    }

   
    void getLastName() {
        assertEquals("lastName", contact.getLastName());
    }

    @Test
    void getPhoneNumber() {
        assertEquals("123456789", contact.getPhoneNumber());
    }

    @Test
    void getAddress() {
        assertEquals("fake address 10111", contact.getAddress());
    }

    @Test
    void testToString() {
        assertEquals("Contact [contactID=1, firstName=firstName, lastName=lastName, phoneNumber=123456789, address=fake street 2101]", contact.toString());
    }

}
